export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], function(md){return(
md`# Import and Export Chord Diagram

Chord diagram to display import and export between contries
Values are shown when hovering on the totals or the chord
`
)});
  main.variable(observer("b1g_coord_diagram")).define("b1g_coord_diagram", ["import_export_coord_diagram"], function(import_export_coord_diagram){return(
import_export_coord_diagram(1)
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## Code`
)});
  main.variable(observer("import_export_coord_diagram")).define("import_export_coord_diagram", ["d3","width","height","chord","M","team_colors","arc","r_out","teams","arc_tip","tippy","ribbon"], function(d3,width,height,chord,M,team_colors,arc,r_out,teams,arc_tip,tippy,ribbon){return(
function import_export_coord_diagram(w) {
  let container = d3.create('div').style('width', `${w * width}px`);
  let svg = container
    .append("svg")
    .style('background-color', 'white')
    .attr("viewBox", [-0.5 * width, -0.5 * height, 1 * width, 1 * height+40])
    .attr("font-size", 10)
    .attr("font-family", "sans-serif");

  let chords = chord(M);
  let arcs = svg
    .append("g")
    .selectAll("g")
    .data(chords.groups)
    .join("g");
  arcs
    .append("path")
    .attr("fill", d => team_colors(d.index)[1])
    .attr("stroke", d => d3.rgb(team_colors(d.index)[1]).darker())
    .attr("d", arc)
  ;
   const group = svg.append("g")
      .attr("font-size", 12)
      .attr("font-family", "sans-serif")
    .selectAll("g")
    .data(chords.groups)
    .join("g");
  group.append("text")
      .each(d => (d.angle = (d.startAngle + d.endAngle) / 2))
      .attr("transform", d => `
        rotate(${(d.angle * 180 / Math.PI - 90)})
        translate(${r_out + 5})
        ${d.angle > Math.PI ? "rotate(180)" : ""}
      `)
      .attr("text-anchor", d => d.angle > Math.PI ? "end" : null)
      .text(d => teams[d.index].name);

  //overlays the arc for tooltip not sure why this is needed
let tooltip = arcs
    .append("path")
    .attr("fill", d => team_colors(d.index)[1])
    .attr("stroke", d => d3.rgb(team_colors(d.index)[1]).darker())
    .attr("d", arc_tip)
    .on('mouseenter', function(d) {
      let this_class = '.' + teams[d.index].name.replace(/ /g, '');
      svg.selectAll('.chord').attr('opacity', 0.1);
      svg.selectAll(this_class).attr('opacity', 1);
    })
    .on('mouseleave', function() {
      svg.selectAll('.chord').attr('opacity', 1);
    })
    .attr('title', function(d) {
      let name = teams[d.index].name;
      let imported = d3.sum(M[d.index]);
      let exported = d3.sum(M.map(r => r[d.index]));
      return `${name} importeerde ${imported} kg uit het buitenland en exporteerde ${exported} kg naar het buitenland.`;
    }); 

  tooltip.nodes().forEach(e =>
    tippy(e, {
      delay: [200, 100],
      duration: [100, 50],
    followCursor:true
    })
  );
  let ribbons = svg
    .append("g")
    .attr('opacity', 0.7)
    .selectAll("path")
    .data(chords)
    .join("path")
    .attr("d", ribbon)
    .attr('class', function(d) {
      let team1 = teams[d.source.index].name.replace(/ /g, '');
      let team2 = teams[d.target.index].name.replace(/ /g, '');
      return `chord ${team1} ${team2}`;
    })
    .attr("fill", d => team_colors(d.source.index)[0])
    .attr("stroke", d => d3.rgb(team_colors(d.source.index)[0]).darker())
    .on('mouseenter', function() {
      svg.selectAll('.chord').attr('opacity', 0.1);
      d3.select(this).attr('opacity', 1);
    })
    .on('mouseleave', function() {
      svg.selectAll('.chord').attr('opacity', 1);
    })
    .attr('title', function(d) {
      let imported1 = M[d.source.index][d.target.index];
      let imported2 = M[d.target.index][d.source.index];
      let team1 = teams[d.source.index].name;
      let team2 = teams[d.target.index].name;
      return `${team1} importeerde ${imported1} kg van ${team2}. ${team2} importeerde ${imported2} kg van ${team1} `;
    });
  ribbons.nodes().forEach(e =>
    tippy(e, {
      delay: [200, 100],
      duration: [100, 50],
      followCursor: true
    })
  );

  return container.node();
}
)});
  main.variable(observer("scale")).define("scale", ["d3","height"], function(d3,height){return(
d3
  .scaleLinear()
  .domain([-1, 1])
  .range([-height / 2, height / 2])
)});
  main.variable(observer("chords")).define("chords", ["chord","M"], function(chord,M){return(
chord(M)
)});
  main.variable(observer("chord")).define("chord", ["d3"], function(d3){return(
d3
  .chord()
  .padAngle(0.1)
  .sortSubgroups(d3.ascending).sortGroups(d3.descending)
)});
  main.variable(observer("arc")).define("arc", ["d3","r","r_out"], function(d3,r,r_out){return(
d3
  .arc()
  .innerRadius(r)
  .outerRadius(r_out)
)});
  main.variable(observer("arc_tip")).define("arc_tip", ["d3","r","r_out"], function(d3,r,r_out){return(
d3
  .arc()
  .innerRadius(r)
  .outerRadius(r_out)
)});
  main.variable(observer("ribbon")).define("ribbon", ["d3","r_out","s"], function(d3,r_out,s){return(
d3.ribbon().radius(r_out-s-10)
)});
  main.variable(observer("team_colors")).define("team_colors", ["d3","teams"], function(d3,teams){return(
d3
  .scaleOrdinal()
  .domain(d3.range(14))
  .range(teams.map(d => d.colors))
)});
  main.variable(observer("s")).define("s", function(){return(
20
)});
  main.variable(observer("r_out")).define("r_out", ["r","s"], function(r,s){return(
r + s
)});
  main.variable(observer("r")).define("r", ["width","height","s"], function(width,height,s){return(
Math.min(width, height) * 0.5 - s
)});
  main.variable(observer("height")).define("height", ["width"], function(width){return(
0.8 * width
)});
  main.variable(observer("colorscale")).define("colorscale", function(){return(
["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf"]
)});
  main.variable(observer("smallData")).define("smallData", ["teams","colorscale"], function(teams,colorscale){return(
teams.map(function(d,i) {
  return {
    name: d.name.toUpperCase(),
    index: i + 1,
    colors  : colorscale.pop
  };
})
)});
  main.variable(observer("tc")).define("tc", ["teams","colorscale"], function(teams,colorscale){return(
teams.forEach(function(team) {
    let color=colorscale.pop();
    team.colors = [ color   , color ];
    colorscale.unshift(color);
})
)});
  main.variable(observer("teams")).define("teams", function(){return(
[
  {idx:0,
  name:"Andy"},
  {idx:2,
  name:"Boris"},
  {idx:3,
  name:"Margo"},
   {idx:4,
  name:"Linn"}
 ]
)});
  main.variable(observer("M")).define("M", function(){return(
[
  [0,11,14,1],
  [11,0,1,1],
  [15,7,0,3],
  [15,7,11,0]
  ]
)});
  main.variable(observer("tippy")).define("tippy", ["require"], function(require){return(
require("https://unpkg.com/tippy.js@2.5.4/dist/tippy.all.min.js")
)});
  main.variable(observer("d3")).define("d3", ["require"], function(require){return(
require("d3@5")
)});
  main.variable(observer("small_import_export_coord_diagram")).define("small_import_export_coord_diagram", ["import_export_coord_diagram"], function(import_export_coord_diagram){return(
import_export_coord_diagram(0.5)
)});
  return main;
}
